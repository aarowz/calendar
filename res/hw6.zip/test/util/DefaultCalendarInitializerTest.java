// Dreshta Boghra & Aaron Zhou
// CS3500 HW6

package util;

/**
 * Testing class for the DefaultCalendarInitializerTest class.
 */
public class DefaultCalendarInitializerTest {
}
